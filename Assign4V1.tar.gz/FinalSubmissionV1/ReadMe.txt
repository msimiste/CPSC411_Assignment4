
To run the program, be sure to have the following files in the directory:

AbsAssign.hs
AST.hs
ErrM.hs
IRDataType.hs
LexAssign.hs
Mainfile.hs
MikeIRGen.hs
ParAssign.hs
Semantic.hs
SkelAssign.hs
ST.hs
SymbolTable.hs


from cmd line run:

ghc --make Mainfile.hs -o Mainfile

To run a test:

./Mainfile <test>


